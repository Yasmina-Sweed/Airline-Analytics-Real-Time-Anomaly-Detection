-- MACRO: Consistent on-time definition (<=15 min)
{% macro is_on_time(delay_column, threshold=15) %}
    CASE 
        WHEN {{ delay_column }} IS NULL THEN NULL
        WHEN {{ delay_column }} <= {{ threshold }} THEN 1
        ELSE 0
    END
{% endmacro %}