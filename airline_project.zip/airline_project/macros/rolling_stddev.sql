-- MACRO: Standard deviation in rolling window
{% macro rolling_stddev(column_name, partition_by, order_by, days=30) %}
    STDDEV({{ column_name }}) OVER (
        PARTITION BY {{ partition_by }}
        ORDER BY {{ order_by }}
        ROWS BETWEEN {{ days }} PRECEDING AND 1 PRECEDING
    )
{% endmacro %}