-- MACRO: Standardize delay categorization
{% macro delay_category(delay_column) %}
    CASE 
        WHEN {{ delay_column }} IS NULL THEN 'Unknown'
        WHEN {{ delay_column }} <= 0 THEN 'Early/On-Time'
        WHEN {{ delay_column }} <= 15 THEN 'Acceptable'
        WHEN {{ delay_column }} <= 60 THEN 'Minor Delay'
        WHEN {{ delay_column }} <= 180 THEN 'Moderate Delay'
        ELSE 'Major Delay'
    END
{% endmacro %}