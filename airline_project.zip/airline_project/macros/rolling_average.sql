-- MACRO: Calculate rolling average (window function)
-- Used in 15+ places in ml_features.sql
{% macro rolling_average(column_name, partition_by, order_by, days=30) %}
    AVG({{ column_name }}) OVER (
        PARTITION BY {{ partition_by }}
        ORDER BY {{ order_by }}
        ROWS BETWEEN {{ days }} PRECEDING AND 1 PRECEDING
    )
{% endmacro %}
