-- MACRO: Safe type casting with default
{% macro safe_cast(column_name, data_type, default_value=0) %}
    COALESCE(TRY_CAST({{ column_name }} AS {{ data_type }}), {{ default_value }})
{% endmacro %}