-- MACRO: Count rows in rolling window
{% macro rolling_count(partition_by, order_by, days=30) %}
    COUNT(*) OVER (
        PARTITION BY {{ partition_by }}
        ORDER BY {{ order_by }}
        ROWS BETWEEN {{ days }} PRECEDING AND 1 PRECEDING
    )
{% endmacro %}