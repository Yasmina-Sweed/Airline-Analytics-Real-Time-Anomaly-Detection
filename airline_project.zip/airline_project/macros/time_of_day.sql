-- MACRO: Categorize hour into time of day
{% macro time_of_day(hour_column) %}
    CASE 
        WHEN {{ hour_column }} BETWEEN 6 AND 11 THEN 'Morning'
        WHEN {{ hour_column }} BETWEEN 12 AND 17 THEN 'Afternoon'
        WHEN {{ hour_column }} BETWEEN 18 AND 21 THEN 'Evening'
        ELSE 'Night/Early Morning'
    END
{% endmacro %}