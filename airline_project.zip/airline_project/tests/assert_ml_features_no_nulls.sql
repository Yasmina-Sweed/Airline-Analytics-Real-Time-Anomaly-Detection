-- Test: Critical ML features must not be null
SELECT
    flight_id,
    CASE 
        WHEN carrier_avg_arrival_delay_30d IS NULL THEN 'carrier_avg_null'
        WHEN route_avg_delay_30d IS NULL THEN 'route_avg_null'
        WHEN distance_miles IS NULL THEN 'distance_null'
        WHEN day_of_week IS NULL THEN 'day_of_week_null'
    END as null_feature
FROM {{ ref('ml_features') }}
WHERE (carrier_avg_arrival_delay_30d IS NULL
       OR route_avg_delay_30d IS NULL
       OR distance_miles IS NULL
       OR day_of_week IS NULL)
  AND flight_date >= '1987-02-01'
