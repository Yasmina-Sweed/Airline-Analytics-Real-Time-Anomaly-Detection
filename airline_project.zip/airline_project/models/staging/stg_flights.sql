{{
    config(
        materialized='table',
        tags=['staging', 'critical']
    )
}}

WITH source AS (
    SELECT * FROM {{ source('raw', 'AIRLINE_RAW_DATA') }}
),

cleaned AS (
    SELECT
        -- PRIMARY KEYS & IDENTIFIERS
        {{ dbt_utils.generate_surrogate_key(['date', 'unique_carrier', 'flight_number', 'origin', 'dest']) }} AS flight_id,
        TRY_CAST(index AS INTEGER) AS source_index,
        
        -- DATE & TIME COLUMNS (Fix VARCHAR → proper types)
        TRY_TO_DATE(date, 'YYYY-MM-DD') AS flight_date,
        TRY_CAST(day_of_month AS INTEGER) AS day_of_month,
        TRY_CAST(month AS INTEGER) AS month,
        YEAR(TRY_TO_DATE(date, 'YYYY-MM-DD')) AS year,
        
        -- Extract time features
        DAYOFWEEK(TRY_TO_DATE(date, 'YYYY-MM-DD')) AS day_of_week,
        DAYNAME(TRY_TO_DATE(date, 'YYYY-MM-DD')) AS day_name,
        
        -- Parse time strings to get hour (for time-of-day features)
        TRY_CAST(SPLIT_PART(scheduled_departure_time, ':', 1) AS INTEGER) AS scheduled_departure_hour,
        TRY_CAST(SPLIT_PART(scheduled_arrival_time, ':', 1) AS INTEGER) AS scheduled_arrival_hour,
        
        -- Keep original time strings for reference
        scheduled_departure_time,
        scheduled_arrival_time,
        actual_departure_time,
        actual_arrival_time,
        
        -- FLIGHT IDENTIFIERS
        UPPER(TRIM(unique_carrier)) AS carrier_code,
        TRY_CAST(flight_number AS INTEGER) AS flight_number,
        UPPER(TRIM(origin)) AS origin_airport,
        UPPER(TRIM(dest)) AS destination_airport,
        
        -- NUMERIC METRICS (Fix VARCHAR → INT/FLOAT)
        TRY_CAST(distance AS INTEGER) AS distance_miles,

        -- Delay metrics (convert to minutes as INTEGER)
        TRY_CAST(departure_delay AS INTEGER) AS departure_delay_minutes,
        TRY_CAST(arrival_delay AS INTEGER) AS arrival_delay_minutes,
        
        -- Elapsed time
        TRY_CAST(actual_elapsed_time AS INTEGER) AS actual_elapsed_minutes,
        TRY_CAST(scheduled_elapsed_time AS INTEGER) AS scheduled_elapsed_minutes,
        
        -- BOOLEAN FLAGS (Fix 'True'/'False' strings → 0/1)
        CASE 
            WHEN UPPER(TRIM(cancelled)) = 'TRUE' THEN 1
            WHEN UPPER(TRIM(cancelled)) = 'FALSE' THEN 0
            ELSE 0  -- Default to not cancelled if NULL
        END AS is_cancelled,
        
        CASE 
            WHEN UPPER(TRIM(diverted)) = 'TRUE' THEN 1
            WHEN UPPER(TRIM(diverted)) = 'FALSE' THEN 0
            ELSE 0  -- Default to not diverted if NULL
        END AS is_diverted,
        
        -- DERIVED METRICS (Add business logic)
        -- On-time performance (within 15 minutes = on time)
        CASE 
            WHEN TRY_CAST(arrival_delay AS INTEGER) IS NULL THEN NULL
            WHEN TRY_CAST(arrival_delay AS INTEGER) <= 15 THEN 1
            ELSE 0
        END AS is_on_time,
        
        -- Delay severity category
        CASE 
            WHEN TRY_CAST(arrival_delay AS INTEGER) IS NULL THEN 'Unknown'
            WHEN TRY_CAST(arrival_delay AS INTEGER) <= 0 THEN 'Early/On-Time'
            WHEN TRY_CAST(arrival_delay AS INTEGER) <= 15 THEN 'Acceptable'
            WHEN TRY_CAST(arrival_delay AS INTEGER) <= 60 THEN 'Minor Delay'
            WHEN TRY_CAST(arrival_delay AS INTEGER) <= 180 THEN 'Moderate Delay'
            ELSE 'Major Delay'
        END AS delay_category,
        
        -- Time of day category
        CASE 
            WHEN TRY_CAST(SPLIT_PART(scheduled_departure_time, ':', 1) AS INTEGER) BETWEEN 6 AND 11 THEN 'Morning'
            WHEN TRY_CAST(SPLIT_PART(scheduled_departure_time, ':', 1) AS INTEGER) BETWEEN 12 AND 17 THEN 'Afternoon'
            WHEN TRY_CAST(SPLIT_PART(scheduled_departure_time, ':', 1) AS INTEGER) BETWEEN 18 AND 21 THEN 'Evening'
            ELSE 'Night/Early Morning'
        END AS time_of_day,
        
        -- Weekend indicator
        CASE 
            WHEN DAYOFWEEK(TRY_TO_DATE(date, 'YYYY-MM-DD')) IN (1, 7) THEN 1  -- Saturday, Sunday
            ELSE 0
        END AS is_weekend,
        
        -- Flight distance category
        CASE 
            WHEN TRY_CAST(distance AS INTEGER) < 500 THEN 'Short (<500mi)'
            WHEN TRY_CAST(distance AS INTEGER) < 1500 THEN 'Medium (500-1500mi)'
            ELSE 'Long (>1500mi)'
        END AS distance_category,
        
        -- DATA LINEAGE & AUDIT
        filename AS source_file,
        loadtimestamp AS loaded_at,
        CURRENT_TIMESTAMP() AS transformed_at
        
    FROM source
    
    -- DATA QUALITY FILTERS
    WHERE 1=1
        -- Must have valid date
        AND TRY_TO_DATE(date, 'YYYY-MM-DD') IS NOT NULL
        -- Must have carrier and airports
        AND unique_carrier IS NOT NULL
        AND origin IS NOT NULL
        AND dest IS NOT NULL
        -- Filter out extreme outliers (optional but recommended)
        AND TRY_CAST(arrival_delay AS INTEGER) BETWEEN -200 AND 2000  -- Max 33 hour delay
        AND TRY_CAST(distance AS INTEGER) > 0
)

SELECT * FROM cleaned
