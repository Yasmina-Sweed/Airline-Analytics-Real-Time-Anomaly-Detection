{{
    config(
        materialized='table',
        tags=['dimension']
    )
}}

WITH all_airports AS (
    -- Get unique airports from both origin and destination
    SELECT DISTINCT origin_airport AS airport_code
    FROM {{ ref('stg_flights') }}
    
    UNION
    
    SELECT DISTINCT destination_airport AS airport_code
    FROM {{ ref('stg_flights') }}
),

airport_stats AS (
    SELECT
        airport_code,
        {{ dbt_utils.generate_surrogate_key(['airport_code']) }} AS airport_key,
        
        -- Calculate statistics for this airport
        COUNT(*) AS total_operations,
        AVG(departure_delay_minutes) AS avg_departure_delay,
        AVG(arrival_delay_minutes) AS avg_arrival_delay,
        AVG(is_cancelled) AS cancellation_rate,
        
        CURRENT_TIMESTAMP() AS created_at
        
    FROM (
        SELECT origin_airport AS airport_code, departure_delay_minutes, 0 as arrival_delay_minutes, is_cancelled
        FROM {{ ref('stg_flights') }}
        UNION ALL
        SELECT destination_airport AS airport_code, 0 as departure_delay_minutes, arrival_delay_minutes, is_cancelled
        FROM {{ ref('stg_flights') }}
    )
    GROUP BY airport_code
)

SELECT * FROM airport_stats
