{{
    config(
        materialized='table',
        tags=['dimension']
    )
}}

WITH date_spine AS (
    SELECT DISTINCT
        flight_date,
        {{ dbt_utils.generate_surrogate_key(['flight_date']) }} AS date_key
    FROM {{ ref('stg_flights') }}
    WHERE flight_date IS NOT NULL
)

SELECT
    date_key,
    flight_date,
    
    -- Date components
    YEAR(flight_date) AS year,
    QUARTER(flight_date) AS quarter,
    MONTH(flight_date) AS month,
    MONTHNAME(flight_date) AS month_name,
    DAY(flight_date) AS day_of_month,
    DAYOFWEEK(flight_date) AS day_of_week,
    DAYNAME(flight_date) AS day_name,
    WEEKOFYEAR(flight_date) AS week_of_year,
    
    -- Business logic
    CASE 
        WHEN DAYOFWEEK(flight_date) IN (1, 7) THEN 1 
        ELSE 0 
    END AS is_weekend,
    
    CASE 
        WHEN DAYOFWEEK(flight_date) = 1 THEN 1
        WHEN DAYOFWEEK(flight_date) = 6 THEN 1
        ELSE 0
    END AS is_peak_travel_day,
    
    -- Seasons
    CASE 
        WHEN MONTH(flight_date) IN (12, 1, 2) THEN 'Winter'
        WHEN MONTH(flight_date) IN (3, 4, 5) THEN 'Spring'
        WHEN MONTH(flight_date) IN (6, 7, 8) THEN 'Summer'
        ELSE 'Fall'
    END AS season,
    
    CURRENT_TIMESTAMP() AS created_at

FROM date_spine
ORDER BY flight_date