{{
    config(
        materialized='table',
        tags=['dimension']
    )
}}

SELECT DISTINCT
    {{ dbt_utils.generate_surrogate_key(['carrier_code']) }} AS carrier_key,
    carrier_code,
    
    -- Carrier full names 
    CASE carrier_code
        WHEN 'AA' THEN 'American Airlines'
        WHEN 'DL' THEN 'Delta Air Lines'
        WHEN 'UA' THEN 'United Airlines'
        WHEN 'WN' THEN 'Southwest Airlines'
        WHEN 'US' THEN 'US Airways'
        ELSE carrier_code
    END AS carrier_name,
    
    -- Performance metrics 
    COUNT(*) OVER (PARTITION BY carrier_code) AS total_flights,
    AVG(departure_delay_minutes) OVER (PARTITION BY carrier_code) AS avg_departure_delay,
    AVG(arrival_delay_minutes) OVER (PARTITION BY carrier_code) AS avg_arrival_delay,
    AVG(is_on_time) OVER (PARTITION BY carrier_code) AS on_time_percentage,
    AVG(is_cancelled) OVER (PARTITION BY carrier_code) AS cancellation_rate,
    
    CURRENT_TIMESTAMP() AS created_at

FROM {{ ref('stg_flights') }}
QUALIFY ROW_NUMBER() OVER (PARTITION BY carrier_code ORDER BY flight_date DESC) = 1
