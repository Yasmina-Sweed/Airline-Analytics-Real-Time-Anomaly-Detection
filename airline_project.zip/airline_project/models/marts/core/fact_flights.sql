{{
    config(
        materialized='incremental',
        unique_key='flight_id',
        tags=['fact']
    )
}}

SELECT
    f.flight_id,
    {{ dbt_utils.generate_surrogate_key(['f.carrier_code']) }} AS carrier_key,
    {{ dbt_utils.generate_surrogate_key(['f.origin_airport']) }} AS origin_airport_key,
    {{ dbt_utils.generate_surrogate_key(['f.destination_airport']) }} AS destination_airport_key,
    {{ dbt_utils.generate_surrogate_key(['f.flight_date']) }} AS date_key,
    
    -- DEGENERATE DIMENSIONS
    f.flight_number,
    f.scheduled_departure_hour,
    f.time_of_day,

    -- MEASURES (numeric facts for aggregation)
    f.departure_delay_minutes,
    f.arrival_delay_minutes,
    f.actual_elapsed_minutes,
    f.scheduled_elapsed_minutes,
    f.distance_miles,

    -- FLAGS (for counting)
    f.is_cancelled,
    f.is_diverted,
    f.is_on_time,
    f.is_weekend,

    -- DERIVED MEASURES
    CASE 
        WHEN f.scheduled_elapsed_minutes > 0 
        THEN f.actual_elapsed_minutes - f.scheduled_elapsed_minutes 
        ELSE NULL 
    END AS elapsed_time_difference,
    
    CASE 
        WHEN f.is_cancelled = 0 AND f.is_on_time = 1 THEN 1
        ELSE 0
    END AS is_successful_on_time_flight,
    
    f.transformed_at,
    CURRENT_TIMESTAMP() AS fact_created_at

FROM {{ ref('stg_flights') }} f

{% if is_incremental() %}
    WHERE TRY_TO_DATE(f.flight_date, 'YYYY-MM-DD') IS NOT NULL
      AND f.flight_date > (SELECT MAX(date_key) FROM {{ this }})
{% else %}
    WHERE TRY_TO_DATE(f.flight_date, 'YYYY-MM-DD') IS NOT NULL
{% endif %}
