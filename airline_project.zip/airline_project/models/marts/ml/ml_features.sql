{{ config(
    materialized='table',
    tags=['ml', 'features']
) }}

WITH base AS (
    SELECT
        flight_id,
        flight_date,
        carrier_code,
        origin_airport,
        destination_airport,
        day_of_week,
        month,
        year,
        scheduled_departure_hour,
        is_weekend,
        distance_miles,
        departure_delay_minutes,
        arrival_delay_minutes,
        is_cancelled,
        is_on_time
    FROM {{ ref('stg_flights') }}
    WHERE arrival_delay_minutes IS NOT NULL
),

carrier_features AS (
    SELECT
        flight_id,
        {{ rolling_average('departure_delay_minutes', 'carrier_code', 'flight_date', 30) }} AS carrier_avg_departure_delay_30d,
        {{ rolling_average('arrival_delay_minutes', 'carrier_code', 'flight_date', 30) }} AS carrier_avg_arrival_delay_30d,
        {{ rolling_average('arrival_delay_minutes', 'carrier_code', 'flight_date', 7) }} AS carrier_avg_arrival_delay_7d,
        {{ rolling_average('is_cancelled::FLOAT', 'carrier_code', 'flight_date', 30) }} AS carrier_cancellation_rate_30d,
        {{ rolling_average('is_on_time::FLOAT', 'carrier_code', 'flight_date', 30) }} AS carrier_on_time_rate_30d,
        {{ rolling_count('carrier_code', 'flight_date', 30) }} AS carrier_flight_count_30d
    FROM base
),

route_features AS (
    SELECT
        flight_id,
        {{ rolling_average('arrival_delay_minutes', 'origin_airport, destination_airport', 'flight_date', 30) }} AS route_avg_delay_30d,
        {{ rolling_average('is_on_time::FLOAT', 'origin_airport, destination_airport', 'flight_date', 30) }} AS route_on_time_rate_30d,
        {{ rolling_count('origin_airport, destination_airport', 'flight_date', 30) }} AS route_flight_count_30d,
        {{ rolling_stddev('arrival_delay_minutes', 'origin_airport, destination_airport', 'flight_date', 30) }} AS route_delay_std_30d
    FROM base
),

airport_features AS (
    SELECT
        flight_id,
        {{ rolling_average('departure_delay_minutes', 'origin_airport', 'flight_date', 7) }} AS origin_avg_departure_delay_7d,
        {{ rolling_average('arrival_delay_minutes', 'destination_airport', 'flight_date', 7) }} AS dest_avg_arrival_delay_7d,
        {{ rolling_count('origin_airport', 'flight_date', 1) }} AS origin_flights_prev_day
    FROM base
),

time_features AS (
    SELECT
        flight_id,
        {{ rolling_average('arrival_delay_minutes', 'carrier_code, day_of_week', 'flight_date', 90) }} AS carrier_dow_avg_delay,
        {{ rolling_average('arrival_delay_minutes', 'carrier_code, month', 'flight_date', 90) }} AS carrier_month_avg_delay,
        {{ rolling_average('arrival_delay_minutes', 'carrier_code, scheduled_departure_hour', 'flight_date', 90) }} AS carrier_hour_avg_delay
    FROM base
)

SELECT
    b.flight_id,
    b.flight_date,
    b.carrier_code,
    b.origin_airport,
    b.destination_airport,
    b.day_of_week,
    b.month,
    b.year,
    b.scheduled_departure_hour,
    b.is_weekend,
    b.distance_miles,
    
    -- Carrier features (exclude flight_id)
    cf.carrier_avg_departure_delay_30d,
    cf.carrier_avg_arrival_delay_30d,
    cf.carrier_avg_arrival_delay_7d,
    cf.carrier_cancellation_rate_30d,
    cf.carrier_on_time_rate_30d,
    cf.carrier_flight_count_30d,
    
    -- Route features
    rf.route_avg_delay_30d,
    rf.route_on_time_rate_30d,
    rf.route_flight_count_30d,
    rf.route_delay_std_30d,
    
    -- Airport features
    af.origin_avg_departure_delay_7d,
    af.dest_avg_arrival_delay_7d,
    af.origin_flights_prev_day,
    
    -- Time features
    tf.carrier_dow_avg_delay,
    tf.carrier_month_avg_delay,
    tf.carrier_hour_avg_delay,
    
    -- Derived features
    CASE 
        WHEN b.scheduled_departure_hour BETWEEN 7 AND 9 THEN 1 
        WHEN b.scheduled_departure_hour BETWEEN 17 AND 19 THEN 1
        ELSE 0 
    END AS is_rush_hour,
    
    {{ time_of_day('b.scheduled_departure_hour') }} AS time_of_day_category,
    
    -- Target variables
    b.departure_delay_minutes AS target_departure_delay,
    b.arrival_delay_minutes AS target_arrival_delay,
    b.is_cancelled AS target_is_cancelled,
    {{ is_on_time('b.arrival_delay_minutes', 15) }} AS target_is_on_time,
    {{ delay_category('b.arrival_delay_minutes') }} AS target_delay_category,
    
    CURRENT_TIMESTAMP() AS features_created_at

FROM base b
LEFT JOIN carrier_features cf ON b.flight_id = cf.flight_id
LEFT JOIN route_features rf ON b.flight_id = rf.flight_id
LEFT JOIN airport_features af ON b.flight_id = af.flight_id
LEFT JOIN time_features tf ON b.flight_id = tf.flight_id

WHERE cf.carrier_avg_arrival_delay_30d IS NOT NULL
  AND rf.route_avg_delay_30d IS NOT NULL
